"""
test_controlnet_pipeline.py - Quick CPU pipeline verification
Tests model architecture, forward pass, ControlNet residual injection, and backward pass.
"""

import torch
import torch.nn.functional as F
from diffusers import ControlNetModel, UNet2DConditionModel

def run_test():
    print("[TEST] Initializing minimal UNet architecture...")
    # Create small UNet with standard SD 1.5 block structure
    unet = UNet2DConditionModel(
        sample_size=64, # 512 / 8 VAE latent size
        in_channels=4,
        out_channels=4,
        layers_per_block=1,
        block_out_channels=(32, 64),
        down_block_types=("CrossAttnDownBlock2D", "DownBlock2D"),
        up_block_types=("UpBlock2D", "CrossAttnUpBlock2D"),
        cross_attention_dim=32,
    )

    print("[TEST] Instantiating ControlNet from UNet...")
    controlnet = ControlNetModel.from_unet(unet)

    # Freeze UNet, train ControlNet
    unet.requires_grad_(False)
    controlnet.requires_grad_(True)
    controlnet.train()

    optimizer = torch.optim.AdamW(controlnet.parameters(), lr=1e-4)

    # Dummy batch
    batch_size = 2
    noisy_latents = torch.randn(batch_size, 4, 64, 64)
    timesteps = torch.tensor([100, 250], dtype=torch.long)
    encoder_hidden_states = torch.randn(batch_size, 77, 32)
    conditioning_sketch = torch.randn(batch_size, 3, 512, 512)
    target_noise = torch.randn_like(noisy_latents)

    print("[TEST] Running ControlNet forward pass...")
    down_block_res_samples, mid_block_res_sample = controlnet(
        noisy_latents,
        timesteps,
        encoder_hidden_states=encoder_hidden_states,
        controlnet_cond=conditioning_sketch,
        return_dict=False
    )

    assert len(down_block_res_samples) > 0, "No down block residuals generated"
    assert mid_block_res_sample is not None, "No mid block residual generated"
    print(f"[TEST] Residual blocks generated: {len(down_block_res_samples)}")

    print("[TEST] Running UNet forward pass with ControlNet residuals...")
    model_pred = unet(
        noisy_latents,
        timesteps,
        encoder_hidden_states=encoder_hidden_states,
        down_block_additional_residuals=down_block_res_samples,
        mid_block_additional_residual=mid_block_res_sample,
        return_dict=False
    )[0]

    assert model_pred.shape == target_noise.shape, f"Shape mismatch: {model_pred.shape} vs {target_noise.shape}"

    print("[TEST] Computing MSE loss and backward pass...")
    loss = F.mse_loss(model_pred, target_noise)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()

    print(f"[PASS] Loss computed: {loss.item():.4f}. Backward pass and optimizer step successful!")

if __name__ == "__main__":
    run_test()

